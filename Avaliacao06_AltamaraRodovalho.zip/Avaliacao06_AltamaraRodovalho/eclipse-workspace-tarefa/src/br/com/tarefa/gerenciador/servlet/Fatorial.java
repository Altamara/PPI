//Exerc�cio 02
package br.com.tarefa.gerenciador.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/doPost")
public class Fatorial extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		super.init();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String num = request.getParameter("numero");
		int x = Integer.parseInt(num);
		int fatorial = 1;
		int i = 1;

		StringBuffer sb = new StringBuffer(
				"<html><head><title>Fatorial</title><p><a href=\"index.html\">Menu</a></p></head>");
		sb.append("<body><h3>Avalia��o 06 PPI - Aluna: Altamara Rodovalho - Exerc�cio 2</h3>");
		sb.append("<h3>Resultado:</h3>");

		while (i <= x) {
			fatorial = fatorial + (fatorial * (x - 1));
			x--;
		}
		String resposta = ("O fatorial do n�mero " + num + " �:  "  + fatorial);
		sb.append(resposta);

		sb.append("</body></html>");
		PrintWriter writer = response.getWriter();
		writer.print(sb);
		writer.close();

	}

	public void destroy() {
		super.destroy();
	}

}
