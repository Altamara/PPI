//Referencia Exercicio 3
package br.com.tarefa.gerenciador.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NomeCorreto
 */
@WebServlet("/NomeCorreto")
public class NomeCorreto extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public NomeCorreto() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		StringBuffer sb = new StringBuffer("<html><head><title>Consulta</title><p><a href=\"index.html\">Menu</a></p></head>");
		sb.append("<body><h3>Avalia��o 06 PPI - Aluna: Altamara Rodovalho - Exercicio 03</h3>");
		
		sb.append("<h1>Ol�, " + request.getParameter("nome") + "!</h1>");
		sb.append("</body></html>");
		
		//response.sendRedirect("index.html");
		PrintWriter writer = response.getWriter();
		writer.print(sb);
		writer.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
