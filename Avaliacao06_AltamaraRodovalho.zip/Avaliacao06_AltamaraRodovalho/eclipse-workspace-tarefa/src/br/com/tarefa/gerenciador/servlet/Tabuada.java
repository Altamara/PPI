//Exerc�cio 01
package br.com.tarefa.gerenciador.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/tabuada")
public class Tabuada extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		super.init();
	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html;charset=ISO=8859=1");
		StringBuffer sb = new StringBuffer(
				"<html><head><title>Tabuada de multiplica��o</title><p><a href=\"index.html\">Menu</a></p></head>");
		sb.append("<body><h3>Avalia��o 06 PPI - Aluna: Altamara Rodovalho</h3>");
		sb.append(
				"<h4>Exercicio 1 - Escreva um Servlet que imprime no HTML a tabuada de multiplica��o dos n�meros de 1 a 10. "
						+ "A mesma deve ser mostrada na forma de tabela HTML: </h4>");

		sb.append("<table border=\"1\"><td colspan=\"10\" align=\"center\">Tabuada de multiplica��o</td><tr>");

		for (int i = 1; i <= 10; i++) {
			sb.append("<td style=\"background-color:#98BF64\">");
			for (int j = 1; j <= 10; j++) {
				int tab = i * j;
				String linha = (i + " x " + j + " = " + tab + "<br>");
				sb.append(linha);
			}
			sb.append("<td>");
			if (i % 5 == 0) {
				sb.append("<tr></tr>");
			}
		}
		sb.append("</tr></table></body></html>");
		PrintWriter out = resp.getWriter();
		out.print(sb);
		out.close();
	}

	public void destroy() {
		super.destroy();
	}

}
