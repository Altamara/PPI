//Exerc�cio 03
package br.com.tarefa.gerenciador.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/doGet")
public class Consulta extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Consulta() {
		super();

	}

	public void init() throws ServletException {
		super.init();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String nome = request.getParameter("nome");

		StringBuffer sb = new StringBuffer("<html><head><title>Consulta</title></head></html>");
		sb.append("<body><h3>Avalia��o 06 PPI - Aluna: Altamara Rodovalho</h3>");
		sb.append(
				"<h4>Exercicio 3 Fa�a um Servlet que recebe um nome e, se ele n�o estiver vazio, escreva �Ol�, nome�. Caso contr�rio, escreva �Ol�, mundo�. "
						+ "Tal c�digo pode ser baseado no exemplo: �stringURL.html� e �GetMethod.java�: </h4>");

		if (nome != null && !nome.trim().isEmpty()) {

			RequestDispatcher dispatcher = request.getRequestDispatcher("/NomeCorreto");
			dispatcher.forward(request, response);

		} else {
			response.sendRedirect("nomeIncorreto.html");
		}

		sb.append("</body></html>");

		PrintWriter writer = response.getWriter();
		writer.print(sb);
		writer.close();
	}

	public void destroy() {
		super.destroy();
	}

}
