package com.tarefa.programa;

import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;//???
import java.text.SimpleDateFormat;

import com.tarefa.dao.ClienteDao;
import com.tarefa.model.Cliente;

public class Programa {
	
	public static void main(String[] args) throws SQLException, ParseException{
		 SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		 
	     Cliente cliente = new Cliente();
	     Cliente cliente1 = new Cliente();
	     Cliente cliente2 = new Cliente();
	     
	     //inser��o do registro
	     cliente.setNomeCliente("Altamara Rodovalho");
	     cliente.setCpfCliente("01405163607");
	     cliente.setEnderecoCliente("Rua Jo�o Tobias, 15");
	     cliente.setBairroCliente("Roosevel");
	     cliente.setCidadeCliente("Uberl�ndia");
	     cliente.setCepCliente("38415000");
	     cliente.setDataNascCliente(new Date(sdf.parse("12/04/1981").getTime()));
	     cliente.setEmailCliente("altamara.rodovalho@ufu.br");
	     cliente.setTelefoneCliente("34999921223");
	     
	     cliente1.setNomeCliente("Julio Cesar Silva de Freitas");
	     cliente1.setCpfCliente("01033277622");
	     cliente1.setEnderecoCliente("Rua Jo�o Tobias, 15");
	     cliente1.setBairroCliente("Roosevelt");
	     cliente1.setCidadeCliente("Uberl�ndia");
	     cliente1.setCepCliente("38415000");
	     cliente1.setDataNascCliente(new Date(sdf.parse("13/07/1977").getTime()));
	     cliente1.setEmailCliente("julio.si.freitas@gmail.com.br");
	     cliente1.setTelefoneCliente("34996349334");
	     
	     cliente2.setNomeCliente("Julia Rodovalho Ribeiro Freitas");
	     cliente2.setCpfCliente("01005177607");
	     cliente2.setEnderecoCliente("Rua Jo�o Tobias, 15");
	     cliente2.setBairroCliente("Roosevelt");
	     cliente2.setCidadeCliente("Uberl�ndia");
	     cliente2.setCepCliente("38415000");
	     cliente2.setDataNascCliente(new Date(sdf.parse("14/05/2022").getTime()));
	     cliente2.setEmailCliente("julia.rr.freitas@gmail.com.br");
	     cliente2.setTelefoneCliente("34996341223");
	     
	     //atualizar o bairro
	     cliente.setBairroCliente("Presidente Roosevelt");
	     cliente.setCpfCliente("01405163607");
	     
	     //atualizar o nome
	     cliente.setNomeCliente("Altamara Rodovalho Ribeiro");
	     cliente.setCpfCliente("01405163607");
	     
	     //deletar cliente
	     cliente.setIdCliente(5);
	     
	     ClienteDao clienteDao = new ClienteDao();
	     
	     //clienteDao.insere(cliente);
	     //clienteDao.insere(cliente1);
	     //clienteDao.insere(cliente2);
	     //clienteDao.atualizarBairro(cliente);
	     //clienteDao.atualizarNome(cliente);
	   
	     //clienteDao.listarCliente();
	     //clienteDao.deletarCliente(cliente);
	}
	
}
