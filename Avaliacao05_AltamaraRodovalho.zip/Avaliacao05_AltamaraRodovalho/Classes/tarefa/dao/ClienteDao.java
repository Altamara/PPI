package com.tarefa.dao;

import java.sql.*;

import com.tarefa.conexao.ConnectionFactory;
import com.tarefa.model.Cliente;

public class ClienteDao {

	private Connection connec = null;

	public ClienteDao() {
		this.connec = new ConnectionFactory().getConnection();
	}

	public void insere(Cliente cliente) throws SQLException {

		String sql = "insert into cliente "
				+ "(Nome_Cliente, CPF_Cliente, Endereco_Cliente, Bairro_Cliente, Cidade_Cliente, Cep_Cliente,"
				+ "DataNasc_Cliente, Email_Cliente, Telefone_Cliente)" + " values (?,?,?,?,?,?,?,?,?)"; // place holder;

		// prepara a conex�o
		PreparedStatement stmt = connec.prepareStatement(sql);
		System.out.println("Conex�o aberta!!!");

		// seta os valores para inser��o
		try {

			stmt.setString(1, cliente.getNomeCliente());
			stmt.setString(2, cliente.getCpfCliente());
			stmt.setString(3, cliente.getEnderecoCliente());
			stmt.setString(4, cliente.getBairroCliente());
			stmt.setString(5, cliente.getCidadeCliente());
			stmt.setString(6, cliente.getCepCliente());
			stmt.setDate(7, cliente.getDataNascCliente());
			stmt.setString(8, cliente.getEmailCliente());
			stmt.setString(9, cliente.getTelefoneCliente());

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			stmt.close();
			System.out.println("Conex�o Finalizada!");
		}
	}

	public void atualizarBairro(Cliente cliente) {

		String sql = "UPDATE CLIENTE SET BAIRRO_CLIENTE=?" + "WHERE CPF_CLIENTE=?";

		try {

			PreparedStatement stmt = connec.prepareStatement(sql);
			stmt.setString(1, cliente.getBairroCliente());
			stmt.setString(2, cliente.getCpfCliente());

			int numLinhasAtualizadas = stmt.executeUpdate();
			System.out.println("Qtde de linhas atualizadas: " + numLinhasAtualizadas);

		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void atualizarNome(Cliente cliente) {

		String sql = "UPDATE CLIENTE SET NOME_CLIENTE=?" + "WHERE CPF_CLIENTE=?";

		try {

			PreparedStatement stmt = connec.prepareStatement(sql);
			stmt.setString(1, cliente.getNomeCliente());
			stmt.setString(2, cliente.getCpfCliente());

			int numLinhasAtualizadas = stmt.executeUpdate();
			System.out.println("Qtde de linhas atualizadas: " + numLinhasAtualizadas);

		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public ResultSet listarCliente() {

		String sql = "select * from cliente";
		
		try {
			Statement st = connec.createStatement();
			ResultSet rs = st.executeQuery(sql);	
			while(rs.next()){ 
				System.out.println(rs.getInt("idCliente") + ", "
			   + rs.getString("Nome_Cliente") + ", "
			   + rs.getString("CPF_Cliente") + ", "
			   + rs.getString("Endereco_Cliente") + ", "
			   + rs.getString("Bairro_Cliente") + ", "
               + rs.getString("Cidade_Cliente"));
			}
			return rs;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void deletarCliente(Cliente cliente) {
		String sql = "DELETE FROM CLIENTE WHERE IDCLIENTE=?";

        try {
            PreparedStatement stmt = connec.prepareStatement(sql);
            stmt.setInt(1, cliente.getIdCliente());

            int numLinhasAtualizadas =  stmt.executeUpdate();
            System.out.println("Qtde de registros apagados: " + numLinhasAtualizadas);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
		
	}
}
