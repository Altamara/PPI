Orientações:
Abrir a Pagina Principal com os links para as demais.
Através da página de cadastro é possível acessar a Página do site (Página Salão)